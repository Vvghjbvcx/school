// Utility functions
function getUsers() {
    let users = localStorage.getItem('users');
    return users ? JSON.parse(users) : [];
}

function saveUser(user) {
    let users = getUsers();
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));
}

function findUser(email) {
    let users = getUsers();
    return users.find(user => user.email === email);
}

function setCurrentUser(email) {
    localStorage.setItem('currentUser', email);
}

function getCurrentUser() {
    return localStorage.getItem('currentUser');
}

function clearCurrentUser() {
    localStorage.removeItem('currentUser');
}

// Registration Form Handling
if (document.getElementById('registrationForm')) {
    document.getElementById('registrationForm').addEventListener('submit', function(e) {
        e.preventDefault();

        let fullName = document.getElementById('fullName').value.trim();
        let email = document.getElementById('email').value.trim();
        let password = document.getElementById('password').value;
        let confirmPassword = document.getElementById('confirmPassword').value;
        let document1 = document.getElementById('document1').files[0];
        let document2 = document.getElementById('document2').files[0];
        let document3 = document.getElementById('document3').files[0];

        // Basic validation
        if (!fullName || !email || !password || !confirmPassword || !document1 || !document2 || !document3) {
            alert('Please fill out all required fields and upload all documents.');
            return;
        }

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        if (findUser(email)) {
            alert('An account with this email already exists.');
            return;
        }

        // Convert documents to data URLs (for demonstration)
        let reader1 = new FileReader();
        let reader2 = new FileReader();
        let reader3 = new FileReader();

        reader1.onload = function() {
            let doc1Data = reader1.result;

            reader2.onload = function() {
                let doc2Data = reader2.result;

                reader3.onload = function() {
                    let doc3Data = reader3.result;

                    // Save user data
                    let user = {
                        fullName: fullName,
                        email: email,
                        password: password,
                        documents: [doc1Data, doc2Data, doc3Data]
                    };

                    saveUser(user);
                    setCurrentUser(email);
                    alert('Registration Successful!');
                    window.location.href = 'dashboard.html';
                };

                reader3.readAsDataURL(document3);
            };

            reader2.readAsDataURL(document2);
        };

        reader1.readAsDataURL(document1);
    });
}

// Login Form Handling
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();

        let email = document.getElementById('emailLogin').value.trim();
        let password = document.getElementById('passwordLogin').value;

        let user = findUser(email);

        if (user && user.password === password) {
            setCurrentUser(email);
            alert('Login Successful!');
            window.location.href = 'dashboard.html';
        } else {
            alert('Invalid email or password.');
        }
    });
}

// Dashboard Page Handling
if (window.location.pathname.endsWith('dashboard.html')) {
    let currentUserEmail = getCurrentUser();

    if (!currentUserEmail) {
        alert('Please log in to access the dashboard.');
        window.location.href = 'login.html';
    } else {
        let user = findUser(currentUserEmail);
        document.getElementById('userFullName').textContent = user.fullName;
        document.getElementById('displayFullName').textContent = user.fullName;
        document.getElementById('displayEmail').textContent = user.email;

        // Handle Logout
        document.getElementById('logoutButton').addEventListener('click', function() {
            clearCurrentUser();
            window.location.href = 'login.html';
        });
    }
}
